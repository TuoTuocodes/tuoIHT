#' Title
#' @param input vector.
#' @return norm.
norm2 = function(input){
  output=sum(input*input)
  return(output)
}

