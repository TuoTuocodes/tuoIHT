#' Title
#'
#' @param X X
#' @param Y Y
#' @param pi s
#'
#' @return solution with IHT
IHT = function(X,Y,pi){
  k=0
  n=nrow(X)
  p=ncol(X)
  beta=matrix(0,p,1)+1
  gt=Tabs(devbeta(beta,X,Y),pi)
  St=Union(supp(beta),gt)
  XS=reduce(St,X)
  betat=sol(X,XS,Y,St)
  Stt=Tabs(betat,pi)
  XSS=reduce(Stt,X)
  betatt=sol(X,XSS,Y,Stt)
  while (sum((betatt-beta)*(betatt-beta))>0.00001){
    beta=betatt
    gt=Tabs(devbeta(beta,X,Y),pi)
    St=Union(supp(beta),gt)
    XS=reduce(St,X)
    betat=sol(X,XS,Y,St)
    Stt=Tabs(betat,pi)
    XSS=reduce(Stt,X)
    betatt=sol(X,XSS,Y,Stt)
  }
  return(betatt)
}
