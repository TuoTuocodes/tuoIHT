#' Title
#'
#' @param input input
#' @param X X
#'
#' @return a matrix with certain columns of X
reduce = function(input,X){
  s=colSums(input)
  n=nrow(X)
  p=ncol(X)
  XS=matrix(0,n,s)
  j=1
  for (i in 1:p){
    if (input[i,]==1){
      XS[,j]=X[,i]
      j=j+1
    }
  }
  return(XS)
}
