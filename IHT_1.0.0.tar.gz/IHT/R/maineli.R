maineli = function(input1,input2){
  output = input1
  p = nrow(output)
  for (i in 1:p){
    if (input2[i,]>0){
      output[i,]=0
    }
  }
  return(output)
}
