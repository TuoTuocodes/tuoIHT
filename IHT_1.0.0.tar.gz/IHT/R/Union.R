#' Title
#'
#' @param input1 1
#' @param input2 2
#'
#' @return return the supp of union of two vector
Union = function(input1,input2){
  p=nrow(input1)
  output=matrix(0,p,1)
  for (i in 1:p){
    if (input1[i,]>0)
      output[i,]=1
  }
  for (i in 1:p){
    if (input2[i,]>0)
      output[i,]=1
  }
  return(output)
}
