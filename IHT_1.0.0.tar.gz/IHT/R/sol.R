#' Title
#'
#' @param X_old X_old
#' @param X X
#' @param Y Y
#' @param index index
#'
#' @return solve a l2 regression problem
sol = function(X_old,X,Y,index){
  n=nrow(X_old)
  p=ncol(X_old)
  output=matrix(0,p,1)
  j=1
  TX=t(X)
  A=TX%*%X
  B=ginv(A)
  C=B%*%TX
  D=C%*%Y
  for (i in 1:p){
    if (index[i,]==1){
      output[i,]=D[j,]
      j=j+1
    }
  }
  return(output)
}
