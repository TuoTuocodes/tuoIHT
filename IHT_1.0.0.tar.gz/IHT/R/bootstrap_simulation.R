#' Bootstrap_simulation
#' This function can help you to estimate Likelihood ratio statistics in Liner least square regression among of high-dimensional data.
#' @param X a n*p martix X with sample size: n and
#' @param s s is size of optimally fitted model.
#' @param q q is the upper α-quantile of bootstrap estomator.
#' @param k number of repeat times
#'
#' @return a list with bootstrap approximations and its upper α-quantile.
#' @export
bootstrap_simulation = function(X,s,q,k=200){
  n=nrow(X)
  output=matrix(0,k,1)
  for (i in 1:k){
    Y=bootstrap_normal(n)
    lr=LR(X,Y,s)
    output[i,]=lr
  }
  m=max(output)+5
  dat=data.frame(output)
  colnames(dat) <- "lr"
  figure=ggplot(dat,aes(x=lr))+geom_density(stat = "density",adjust=1.5)+xlim(0,25)
  quantile=unname(quantile(output,1-q))
  output_data=list(output,quantile,figure)
  return(output_data)
}
