#' Title
#'
#' @param input index
#' @param X X
#'
#' @return truncation

truncation = function(input,X){
  n=nrow(X)
  p=ncol(X)
  XS=matrix(0,n,p)
  for (i in 1:n){
    if (input[i,]==1){
      XS[i,]=X[i,]
    }
  }
  return(XS)
}
