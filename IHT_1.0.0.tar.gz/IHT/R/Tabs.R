#' Title
#'
#' @param input input
#' @param pi pi
#'
#' @return return the location of top max pi elements
Tabs = function(input,pi){
  ab=abs(input)
  row=nrow(ab)
  output=matrix(0,row,1)
  index=order(ab,decreasing=TRUE)[1:pi]
  for (i in 1:pi){
    k=index[i]
    output[k,]=1
  }
  return(output)
}
