#' Title
#' @param n number of times of boostrap
#' @return n different std normal variables
bootstrap_normal = function(n){
  r = matrix(0,n,1)
  for (i in 1:n){
    r[i,]=rnorm(1)
  }
  return(r)
}
