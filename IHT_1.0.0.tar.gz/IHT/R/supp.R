#' Title
#'
#' @param input vector
#'
#' @return return supp of a vector
supp = function(input){
  p=nrow(input)
  output=matrix(0,p,1)
  for (i in 1:p){
    if (abs(input[i,])>0)
      output[i,]=1
  }
  return(output)
}
