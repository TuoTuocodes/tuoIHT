#' Title
#'
#' @param e e
#' @param n n
#' @param p p
#'
#' @return X
#' @export
Xtest = function(e,n,p){
  sigma = matrix(0,p,p)
  for (i in 1:p){
    for (j in 1:p){
      k = abs(i-j)
      sigma[i,j] = e^k
    }
  }
  mu = matrix(0,p,1)
  Xtest = mvrnorm(n,mu,sigma)
  output = scale(Xtest,center=TRUE,scale=TRUE)
  return(output)
}
