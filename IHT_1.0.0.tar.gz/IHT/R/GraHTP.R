#' Title
#'
#' @param X X
#' @param Y Y
#' @param pi selection size
#' @param s step size
#'
#' @return soluation with GraHTP
#' @export
GraHTP = function(X,Y,pi,s){
  k=0
  n=nrow(X)
  p=ncol(X)
  beta=matrix(0,p,1)
  betastar = beta - s*devbeta(beta,X,Y)
  St = supp(Tabs(betastar,pi))
  XS=reduce(St,X)
  betatt=sol(X,XS,Y,St)
  while (sum((betatt-beta)*(betatt-beta))>0.0001){
    beta=betatt
    betastar = beta - s*devbeta(beta,X,Y)
    St = supp(Tabs(betastar,pi))
    XS=reduce(St,X)
    betatt=sol(X,XS,Y,St)
  }
  return(betatt)
}

