#' Title
#'
#' @param X X
#' @param Y Y
#' @param pi selection siza
#' @param l extend size
#'
#' @return soluation with two_stage_IHT
#' @export
IHT2 = function(X,Y,pi,l){
  k=0
  n=nrow(X)
  p=ncol(X)
  beta=matrix(0,p,1)+0.1
  su = supp(beta)
  cutbeta = maineli(devbeta(beta,X,Y),su)
  gt = Tabs(cutbeta,l)
  St=Union(su,gt)
  XS=reduce(St,X)
  betat=sol(X,XS,Y,St)
  Stt=Tabs(betat,pi)
  XSS=reduce(Stt,X)
  betatt=sol(X,XSS,Y,Stt)
  while (sum((betatt-beta)*(betatt-beta))>0.000001){
    beta=betatt
    su = supp(beta)
    cutbeta = maineli(devbeta(beta,X,Y),su)
    gt = Tabs(cutbeta,l)
    St=Union(su,gt)
    XS=reduce(St,X)
    betat=sol(X,XS,Y,St)
    Stt=Tabs(betat,pi)
    XSS=reduce(Stt,X)
    betatt=sol(X,XSS,Y,Stt)
  }
  return(betatt)
}
