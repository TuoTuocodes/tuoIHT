#' Title
#'
#' @param X X
#' @param Y Y
#' @param s s
#'
#' @return likelihood ratio
LR = function(X,Y,s){
  solution=IHT(X,Y,s)
  A=norm2(Y)
  epi=Y-X%*%solution
  B=norm2(epi)
  output=A-B
}
