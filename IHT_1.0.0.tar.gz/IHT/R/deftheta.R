#' Title
#' @param p p
#' @param s s
#' @return theta
#' @export
deftheta = function(p,s){
  output = matrix(0,p,1)
  for (i in 1:s){
    output[i,]=1
  }
  return(output)
}
