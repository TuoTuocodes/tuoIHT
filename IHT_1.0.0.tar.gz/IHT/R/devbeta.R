#' Title
#'
#' @param input vector
#' @param X X
#' @param Y Y
#'
#' @return  dev of the loss function
devbeta =  function(input,X,Y){
  beta=input
  TX=t(X)
  output=TX%*%X%*%beta-TX%*%Y
  return(output)
}

